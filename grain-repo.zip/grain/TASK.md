# TASK.md

## Active phase
**Phase 1 — Codebase / feature completion**

## Now
- [ ] Split `src/game.js` into modules: `board/` (pure logic), `render/`, `fx/`, `audio/`, `input/`, `ui/`, `config.ts`
- [ ] Convert to TypeScript (strict)
- [ ] Unit tests (Vitest) for: placement, clear detection, scoring, piece outline generation, piece-set fairness

## Next
- Settings screen (sound, music, haptics, reduce motion)
- Pause / home screen

## Done
- [x] Playable prototype: 3D carved blocks, ghost preview, clear FX, combos, save/resume (v0.1.0)
